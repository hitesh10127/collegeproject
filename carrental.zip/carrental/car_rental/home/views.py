from django.shortcuts import render,redirect
from django.shortcuts import HttpResponse
from django. http import JsonResponse
from  .models import carproduct_master,carorder_master,user_contact,signup_master

# Create your views here.
def home(request):
    return HttpResponse('<h1>hello world</h1>')
def index(request):
    return render(request,'index.html')
 
def rentcar(request):
    return render(request,'rentcar.html')
def contact(request):
 if request.method=='POST':
        name=request.POST['name']
        email=request.POST['email']
        message=request.POST['message']
        ob=user_contact.objects.create(name=name,email=email,message=message)
        return render(request,'contact.html',{'output':'register sucessfully'})
    
 return render(request,'contact.html')
def about(request):
    return render(request,'about.html')
def blog(request):
    return render(request,'blog.html')
def login(request):
    if request.method=="POST":
        ano=request.POST["ano"]
        password=request.POST["password"]
        try:
            ob=signup_master.objects.get(ano=ano,password=password)
            if ob.role_name=='admin':
                obj=signup_master.objects.all()
                # return render(request,'order.html',{'user':obj})
                return redirect("http://127.0.0.1:8000/order")
            elif ob.role_name=='user':
                # return render(request,'order.html',{'user':ob})
            
                return redirect("http://127.0.0.1:8000/order",{'data':ob})
            else:
                return render(request,'login.html')
        except Exception as e:
            return render(request,'login.html',{'data':'invalid'+str(e)})
                
    return render(request,'login.html') 
def signup(request):
    if request.method=="POST":
        name=request.POST["name"]
        password=request.POST["password"]
        role_name=request.POST["role_name"]
        email=request.POST["email"]
        ano=request.POST["ano"]
        ob=signup_master.objects.create(name=name,password=password,role_name=role_name,email=email,ano=ano)
        ob.save()
        return render(request,'signup.html',{'output':"register sucessefully"})
    return render(request,'signup.html')
def creta(request):
    return render(request,'creta.html')
def verna(request):
    return render(request,'verna.html')
def thar(request):
    return render(request,'thar.html')
def fortuner(request):
    return render(request,'fortuner.html')
def venue(request):
    return render(request,'venue.html')
def nexon(request):
    return render(request,'nexon.html')
def harrier(request):
    return render(request,'harrier.html')
def mghactor(request):
    return render(request,'mghactor.html')
def salvia(request):
    return render(request,'salvia.html')
def i20(request):
    return render(request,'i20.html')
def grandvitara(request):
    return render(request,'grandvitara.html')
def seltos(request):
    return render(request,'seltos.html')
def order(request):
    data=carproduct_master.objects.all()
    if request.method=="POST":
        pobj=carproduct_master.objects.get(pid=request.POST['pid'])
        product ={
            'prate':pobj.prate,
            'pqty':pobj.pqty
        }
        
        return JsonResponse({'product':product})
    return render(request,'order.html',{"products":data})
def ordercreate(request):
    data=carproduct_master.objects.all()
    if request.method=="POST":
        prate=request.POST['prate']
        oqty=request.POST['pqty'] 
        oname=request.POST['oname'] 
        
        
        pid=request.POST['pid']
        oval=int(oqty)*int(prate)
        obj=carorder_master.objects.create(pid=pid,prate=prate,oqty=oqty,ovalue=oval,oname=oname ) 
        obj.save()
        return render(request,'order.html',{"products":data})
