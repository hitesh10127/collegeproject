from django.db import models
from django.utils import timezone

# Create your models here.
class signup_master(models.Model):
    name=models.CharField(max_length=30  )
    ano=models.CharField(max_length=20,primary_key=True)
    password=models.CharField(max_length=20 ,unique=True)
    email=models.CharField(max_length=10 )
    role_name=models.CharField(max_length=10)
    def __str__(self):
        return self.name 
class carproduct_master(models.Model):
    pid=models.AutoField(primary_key=True)
    pname=models.CharField(max_length=20)
    prate=models.IntegerField(default=0)
    pqty=models.IntegerField(default=0)
      
    def __str__(self):
        return self.pname
class carorder_master(models.Model):
         oid=models.AutoField(primary_key=True)
         odate=models.DateField(default=timezone.now)
           
         pid=models.IntegerField()
         prate=models.IntegerField(default=0)
         oqty=models.IntegerField(default=0)
         ovalue=models.CharField(max_length=100) 
         oname=models.CharField(max_length=100)    
          
 
class user_contact(models.Model):
    name=models.CharField(max_length=50)
    email=models.CharField(max_length=60)
    message=models.CharField(max_length=600)
    def __str__(self):
        return self.name    