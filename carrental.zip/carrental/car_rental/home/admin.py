from django.contrib import admin

# Register your models here.
from .models import carproduct_master
admin.site.register(carproduct_master)

from .models import carorder_master
admin.site.register(carorder_master)

from .models import signup_master 
admin.site.register(signup_master) 

from .models import user_contact 
admin.site.register(user_contact)
