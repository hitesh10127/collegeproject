"""
URL configuration for car_rental project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin 
from django.urls import path
from home import views as hviews

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home',hviews.home),
    path('index',hviews.index),
     
    path('rentcar',hviews.rentcar),
    path('contact',hviews.contact),
    path('about',hviews.about),
    path('blog',hviews.blog),
     path('login',hviews.login),
     path('signup',hviews.signup),
     path('creta',hviews.creta),
     path('verna',hviews.verna),
     path('thar',hviews.thar),
     path('fortuner',hviews.fortuner),
     path('venue',hviews.venue),
     path('nexon',hviews.nexon),
     path('harrier',hviews.harrier),
     path('mghactor',hviews.mghactor),
     path('salvia',hviews.salvia),
     path('i20',hviews.i20),
     path('grandvitara',hviews.grandvitara),
     path('seltos',hviews.seltos),
     path('order',hviews.order),
      path('ordercreate',hviews.ordercreate),
]
